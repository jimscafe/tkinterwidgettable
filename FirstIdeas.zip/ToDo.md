* Entry widget lost focus - changes kept, data is updated
* Reduce number of rows below the number of visible rows after populating the full 
  matrix of widgets
* Rename some variable with more accurate names (e.g. trow, tcol)
* getText -> getValue? 
* Background color (style) of a column of ttk.Combobox
* Modify how a widget can be disabled.enabled (rows not used) and how data cells
  can be enabled/disabled.
* Foreground and background color setting need better code
* Encapsulate more - perhaps have the widget hold the data details
Improve the initializing of the table
Improve the drawing of the cell in the parent
Improve the api of the data changes to the parent.
